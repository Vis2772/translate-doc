#!/usr/bin/env python3
"""Babelivre flow composer.

Re-typesets a translated book as one continuous flow: every output page is
filled to the bottom margin, text may split across pages, and pages that
start mid-way through an original page carry a small
«— suite de la page N —» caption. Illustrations become dedicated full
pages (or inline blocks for small ones). No wasted white space.

Layout accuracy rules implemented here:
  * first-line indent only (continuation lines use the full column width)
  * widow control: a lone word on the last line is pulled up (compressed
    word spacing) or accompanied by the previous word
  * table-of-contents blocks (short multi-line entries merged into one
    paragraph by the layout model) are split back into one entry per line
  * isolated glyphs (●, *, —) are rendered as centered scene breaks
  * sentences split across two layout blocks (or two pages) are re-joined

Usage:
    flow_compose.py <source.pdf> <output.pdf> [--li en] [--lo fr]
                    <flow1.json> [flow2.json ...]
"""

import json
import re
import sys
from bisect import bisect_left
from collections import Counter
from statistics import median

import pymupdf

try:
    import pyphen
except ImportError:
    pyphen = None

LINE_FACTOR = 1.32          # line height = size * LINE_FACTOR
PARA_GAP_EM = 0.55          # gap after non-indented paragraphs
ENTRY_GAP_EM = 0.18         # gap between split list/TOC entries
HEAD_BEFORE_EM = 1.10       # space before headings
HEAD_AFTER_EM = 0.35        # space after headings
CAPTION_SIZE = 9.0
PAGENUM_SIZE = 8.5
PLATE_RATIO = 0.40          # image area ratio above which => dedicated page
IMG_MIN_RATIO = 0.015       # ignore images below this page fraction
IMG_DPI = 150
INLINE_DPI = 130
TEXT_COLOR = (0.10, 0.09, 0.08)
MUTE_COLOR = (0.47, 0.43, 0.38)
JUSTIFY_MAX_STRETCH = 1.8   # max extra space (x normal space) per gap
WIDOW_MIN_GAP = 0.75        # min inter-word gap (x normal) when compressing
LINELIST_MARGIN = 2.5       # a multi-line block ending this far (x size)
                            # short of the column edge is a line list

FONTS = None  # lazily built per run
TRANSLATOR = None  # optional per-line translator for TOC entries
HYPH = None  # pyphen hyphenator for the output language

# words that indicate a sentence continues on the next block/page
FUNCT_WORDS = {
    "the", "a", "an", "and", "of", "to", "in", "on", "for", "with", "from",
    "by", "at", "as", "that", "this", "was", "were", "is", "are", "his",
    "her", "its", "their", "our", "or", "but", "not", "be", "been",
    "le", "la", "les", "un", "une", "des", "du", "de", "et", "au", "aux",
    "dans", "pour", "avec", "sur", "par", "que", "qui", "est", "était",
    "son", "sa", "ses", "leur", "leurs", "ou", "où", "plus", "très",
}


def build_fonts():
    return {
        (False, False): pymupdf.Font("tiro"),
        (True, False): pymupdf.Font("tibo"),
        (False, True): pymupdf.Font("tiit"),
        (True, True): pymupdf.Font("tibi"),
    }


def make_hyphenator(lang_out):
    """Hyphenator for the OUTPUT language (we re-typeset translated text)."""
    if not pyphen or not lang_out:
        return None
    for cand in (f"{lang_out}_{lang_out.upper()}", lang_out):
        try:
            return pyphen.Pyphen(lang=cand)
        except Exception:
            continue
    return None


def make_translator(lang_in, lang_out):
    """Best-effort Google translator (same free endpoint as pdf2zh)."""
    if not lang_in or not lang_out:
        return None
    try:
        from pdf2zh.translator import GoogleTranslator

        return GoogleTranslator(lang_in, lang_out, None)
    except Exception:
        return None


def translate_line(text):
    if TRANSLATOR is None:
        return None
    try:
        out = TRANSLATOR.translate(text)
        if out and "IRREPARABLE" not in out:
            return out.strip()
    except Exception:
        pass
    return None


def letters(s):
    return len(re.findall(r"[A-Za-zÀ-ÿ]", s))


def digits(s):
    return len(re.findall(r"[0-9]", s))


PAGENUM_RE = re.compile(
    r"^[\s\-–—.|•*]*[0-9ivxlcdm]+[\s\-–—.|•*]*$", re.IGNORECASE
)

TERMINAL_RE = re.compile(r'[.!?…:;»"』」\)]\s*[»"“”]?\s*$')


def ends_sentence(s):
    return bool(TERMINAL_RE.search(s.rstrip()))


def last_word(s):
    m = re.search(r"([A-Za-zÀ-ÿ']+)\s*$", s)
    return m.group(1).lower() if m else ""


def sanitize(s):
    s = s.replace("\ufffd", "").replace("\u25cf", "\u2022")
    s = "".join(ch for ch in s if ch >= " " or ch == "\t")
    s = " ".join(s.split())
    # keep a space between a bullet and the following word
    s = re.sub(r"([\u2022\u25aa\u25e6\u00b7])(?=[A-Za-z\u00c0-\u00ff])", r"\1 ", s)
    # harmonize dialogue quotes to French guillemets
    if s.count('"') >= 2 and s.count('"') % 2 == 0:
        s = re.sub(r'"([^"]*)"', r"« \1 »", s)
    return s


def font_for(name):
    bold = bool(re.search(r"bold|black|heavy|semib|demi", name or "", re.I))
    ital = bool(re.search(r"ital|oblique|kursiv", name or "", re.I))
    return FONTS[(bold, ital)], bold, ital


def image_blocks(page):
    """Meaningful image rectangles of a page, merged when overlapping."""
    pr = page.rect
    parea = pr.get_area()
    rects = []
    for info in page.get_image_info():
        r = pymupdf.Rect(info["bbox"])
        if r.is_empty or r.is_infinite:
            continue
        inter = r & pr
        if inter.is_empty or inter.get_area() < IMG_MIN_RATIO * parea:
            continue
        rects.append(inter)
    merged = []
    for r in sorted(rects, key=lambda r: (r.y0, r.x0)):
        for m in merged:
            if m.intersects(r):
                m |= r
                break
        else:
            merged.append(pymupdf.Rect(r))
    # A near-full-page image behind real text is a background texture: ignore.
    has_text = letters(page.get_text()) > 40
    if has_text:
        merged = [
            r for r in merged if r.get_area() < 0.96 * parea
        ]
    return merged


def load_pages(json_paths):
    pages = {}
    for p in json_paths:
        with open(p, "r", encoding="utf-8") as f:
            for pg in json.load(f)["pages"]:
                pages[pg["pageid"]] = pg
    return [pages[k] for k in sorted(pages)]


def line_width(ln, font, size):
    space = font.text_length(" ", size)
    return (
        sum(font.text_length(w, size) for w in ln)
        + space * (len(ln) - 1)
    )


def wrap_words(text, font, size, width, first_width=None):
    """Split text into lines (lists of words) that fit `width`.

    `first_width` (if given) applies to the first line only — used for
    first-line paragraph indentation.
    """
    words = text.split()
    if not words:
        return []
    widths = [width, width]
    if first_width is not None:
        widths[0] = first_width
    space = font.text_length(" ", size)
    lines = []
    cur, curw, li = [], 0.0, 0
    for w in words:
        ww = font.text_length(w, size)
        # A single word wider than the column is hard-split.
        while ww > widths[li] and widths[li] > 10:
            if cur:
                lines.append(cur)
                cur, curw = [], 0.0
                li = min(li + 1, 1)
            acc, n = 0.0, 0
            while n < len(w) and (
                acc + font.text_length(w[n], size) <= widths[li] or n == 0
            ):
                acc += font.text_length(w[n], size)
                n += 1
            n = max(n, 1)
            lines.append([w[:n]])
            w = w[n:]
            ww = font.text_length(w, size)
        add = ww if not cur else ww + space
        if cur and curw + add > widths[li]:
            # try to hyphenate the word into the end of the current line
            # (lowercase words only, min 3 chars on each side, never the
            # final word of the paragraph — that would leave a lone fragment)
            if (
                HYPH is not None
                and len(w) >= 5
                and w[0].islower()
                and w is not words[-1]
            ):
                rem = widths[li] - curw - space
                best = None
                for pos in HYPH.positions(w):
                    if pos < 3 or pos > len(w) - 3:
                        continue
                    if font.text_length(w[:pos] + "-", size) <= rem:
                        best = pos
                if best is not None:
                    cur.append(w[:best] + "-")
                    lines.append(cur)
                    w = w[best:]
                    ww = font.text_length(w, size)
                    cur, curw = [w], ww
                    li = min(li + 1, 1)
                    continue
            lines.append(cur)
            cur, curw = [w], ww
            li = min(li + 1, 1)
        else:
            cur.append(w)
            curw += add
    if cur:
        lines.append(cur)
    return lines


def fix_widows(lines, font, size, width, absorb_width=None):
    """Avoid a lone short word on the last line of a paragraph.

    1. try to pull the widow up by compressing the previous line's spacing
    2. otherwise push the previous line's last word down (2-word last line)

    `absorb_width` is the available width of the line that absorbs the
    widow (the first line when the paragraph has exactly two lines).
    """
    if len(lines) < 2:
        return lines
    # a paragraph must not end on a hyphen-split fragment: rejoin the
    # pieces into a whole word before applying widow control
    prev, last = lines[-2], lines[-1]
    if (
        len(last) == 1
        and prev
        and prev[-1].endswith("-")
        and last[0][:1].islower()
    ):
        word = prev[-1][:-1] + last[0]
        if len(prev) == 1:
            lines[-2] = [word]
            lines.pop()
        else:
            lines[-2] = prev[:-1]
            lines[-1] = [word]
        prev, last = lines[-2], lines[-1]
    if len(last) != 1 or len(last[0]) > 12:
        return lines
    widow = last[0]
    if len(prev) >= 2:
        space = font.text_length(" ", size)
        words = prev + [widow]
        ww = sum(font.text_length(w, size) for w in words)
        avail = absorb_width if absorb_width is not None else width
        if ww + WIDOW_MIN_GAP * space * (len(words) - 1) <= avail:
            lines[-2] = words
            lines.pop()
            return lines
    if len(prev) >= 4:
        lines[-1] = [prev[-1], widow]
        lines[-2] = prev[:-1]
    return lines


class FlowBook:
    def __init__(self, src, out, pages, stats):
        self.src = src
        self.out = out
        self.pages = pages
        self.pw, self.ph = stats["page_size"]
        self.left, self.right = stats["content"]
        self.top = stats["top"]
        self.bottom = stats["bottom"]
        self.body = stats["body"]
        self.width = self.right - self.left
        self.page = None
        self.tw = None
        self.y = 0.0
        self.text_started = set()  # origins whose flowing content began
        self.first_out = {}
        self.count = 0
        self.redacted = set()

    # ---------- page management ----------
    def finish_page(self):
        if self.page is None:
            return
        self.tw.write_text(self.page, color=TEXT_COLOR)
        num = str(len(self.out))
        fw = FONTS[(False, False)].text_length(num, PAGENUM_SIZE)
        self.page.insert_text(
            ((self.pw - fw) / 2, self.ph - 22),
            num,
            fontname="tiro",
            fontsize=PAGENUM_SIZE,
            color=MUTE_COLOR,
        )
        self.page = None
        self.tw = None

    def new_page(self, origin):
        # caption only when this output page continues an original page
        # whose flowing content already started on an earlier output page
        need_caption = origin is not None and origin in self.text_started
        self.page = self.out.new_page(width=self.pw, height=self.ph)
        self.count += 1
        self.tw = pymupdf.TextWriter(self.page.rect)
        self.y = self.top
        if need_caption:
            self._caption(origin)

    def ensure_page(self, origin):
        if self.page is None:
            self.new_page(origin)

    def _caption(self, origin):
        text = f"— suite de la page {origin + 1} —"
        f = FONTS[(False, True)]
        w = f.text_length(text, CAPTION_SIZE)
        x = self.left + (self.width - w) / 2
        self.tw.append((x, self.y - CAPTION_SIZE * 0.2), text, font=f,
                       fontsize=CAPTION_SIZE)
        self.tw.write_text(self.page, color=MUTE_COLOR)
        self.tw = pymupdf.TextWriter(self.page.rect)
        self.y += CAPTION_SIZE * 1.1

    def mark_origin(self, origin):
        """Record the output page where an original page's content starts."""
        if origin is None:
            return
        if origin not in self.first_out:
            self.first_out[origin] = (
                len(self.out) if self.page is not None else len(self.out) + 1
            )

    # ---------- placement ----------
    def remaining(self):
        return self.bottom - self.y

    def place_text(self, item):
        size = item["size"]
        font, bold, ital = font_for(item["font"])
        style = FONTS[(bold, ital)]
        lh = size * LINE_FACTOR
        entry = item.get("entry", False)
        indent = item["indent"] and not item["heading"] and not entry
        x_first = self.left + (size if indent else 0)
        # only the FIRST line is indented; continuation lines use the
        # full column width
        lines = wrap_words(
            item["text"], style, size,
            self.right - self.left,
            first_width=self.right - x_first,
        )
        if not lines:
            return
        if not entry:
            lines = fix_widows(
                lines, style, size,
                self.right - self.left,
                absorb_width=(
                    self.right - x_first if len(lines) == 2 else None
                ),
            )
        self.ensure_page(item["origin"])

        # spacing before
        before = 0.0
        if item["heading"]:
            before = size * HEAD_BEFORE_EM
        elif entry:
            # a dialogue entry (crowd shouts split per line) keeps the
            # full paragraph gap, not the tight list-entry gap
            before = self.body * (
                PARA_GAP_EM if item["text"].startswith("«") else ENTRY_GAP_EM
            )
        elif not indent and self.y > self.top:
            before = self.body * PARA_GAP_EM
        if before and self.y > self.top + 0.5:
            self.y += before

        # keep-with-next rules
        need_head = 0.0
        if item["heading"]:
            need_head = size * LINE_FACTOR + 2 * self.body * LINE_FACTOR
        elif len(lines) > 1:
            # never leave a single line of a paragraph at the bottom of
            # a page (page-break widow)
            need_head = 2 * lh
        if need_head and self.y > self.top + 0.5 and self.remaining() < need_head:
            self.finish_page()
            self.new_page(item["origin"])

        placed_any = False
        for li, ln in enumerate(lines):
            is_last = li == len(lines) - 1
            # never leave a lone short word as the last line of a page
            # when the paragraph continues on the next page
            if (
                not is_last
                and len(ln) == 1
                and len(ln[0]) <= 12
                and self.y > self.top + 0.5
                and self.remaining() < 2 * lh
            ):
                self.finish_page()
                self.new_page(item["origin"])
            if self.remaining() < lh:
                self.finish_page()
                self.new_page(item["origin"])
            # first line keeps the paragraph indent; continuation lines
            # (incl. after a page break) always start at the left margin
            x0 = x_first if li == 0 else self.left
            width = self.right - x0
            self._line(
                ln, style, size, x0, width,
                justify=(not is_last and not item["heading"] and not entry),
            )
            if not placed_any:
                placed_any = True
                self.text_started.add(item["origin"])
            self.y += lh
        if item["heading"]:
            self.y += size * HEAD_AFTER_EM

    def _line(self, ln, font, size, x, width, justify=True):
        space = font.text_length(" ", size)
        words_width = sum(font.text_length(w, size) for w in ln)
        natural = words_width + space * (len(ln) - 1)
        gap = space
        if len(ln) > 1:
            if natural < width:
                if (
                    justify
                    and (width - natural) / (len(ln) - 1)
                    <= space * JUSTIFY_MAX_STRETCH
                ):
                    gap = space + (width - natural) / (len(ln) - 1)
            elif natural > width:
                # compressed spacing (widow pull-up): squeeze gaps to fit
                gap = max(
                    (width - words_width) / (len(ln) - 1),
                    WIDOW_MIN_GAP * space,
                )
        cx = x
        baseline = self.y + size * 0.84
        for w in ln:
            self.tw.append((cx, baseline), w, font=font, fontsize=size)
            cx += font.text_length(w, size) + gap

    def place_centered(self, item):
        """Centered heading / number."""
        size = item["size"]
        font, bold, ital = font_for(item["font"])
        style = FONTS[(bold, ital)]
        lh = size * LINE_FACTOR
        lines = wrap_words(item["text"], style, size, self.width)
        if not lines:
            return
        self.ensure_page(item["origin"])
        before = size * HEAD_BEFORE_EM if self.y > self.top + 0.5 else 0
        need = before + len(lines) * lh + 2 * self.body * LINE_FACTOR
        if need > self.remaining() and self.y > self.top + 0.5:
            self.finish_page()
            self.new_page(item["origin"])
            before = 0
        self.y += before
        placed_any = False
        for ln in lines:
            if self.remaining() < lh:
                self.finish_page()
                self.new_page(item["origin"])
            natural = line_width(ln, style, size)
            cx = self.left + max((self.width - natural) / 2, 0)
            baseline = self.y + size * 0.84
            for w in ln:
                self.tw.append((cx, baseline), w, font=style, fontsize=size)
                cx += style.text_length(w, size) + style.text_length(" ", size)
            if not placed_any:
                placed_any = True
                self.text_started.add(item["origin"])
            self.y += lh
        self.y += size * HEAD_AFTER_EM

    def place_scene_break(self, item):
        """Centered scene separator (●, *, — …)."""
        size = min(item["size"], self.body * 1.1)
        font, _, _ = font_for(item["font"])
        style = FONTS[(False, False)]
        lh = size * LINE_FACTOR
        need = lh + 2 * self.body * 0.45
        self.ensure_page(item["origin"])
        if self.y > self.top + 0.5:
            if self.remaining() < need:
                self.finish_page()
                self.new_page(item["origin"])
            self.y += self.body * 0.45
        text = item["text"].strip() or "\u2022"
        w = style.text_length(text, size)
        if w > self.width:
            text = "\u2022"
            w = style.text_length(text, size)
        cx = self.left + max((self.width - w) / 2, 0)
        baseline = self.y + size * 0.84
        self.tw.append((cx, baseline), text, font=style, fontsize=size)
        self.text_started.add(item["origin"])
        self.y += lh + self.body * 0.45

    def _clean_src_page(self, pno, blocks, pars_td):
        """Redact flowing text that overlaps image blocks so rendered
        bitmaps show art only, without the English text."""
        if pno in self.redacted or not blocks:
            return
        page = self.src[pno]
        annots = []
        for (x0, x1, top, bot, has_trans) in pars_td:
            if not has_trans:
                continue
            r = pymupdf.Rect(x0 - 1, top - 1, x1 + 1, bot + 1)
            if any(r.intersects(b) for b in blocks):
                annots.append(r)
        if annots:
            try:
                for r in annots:
                    page.add_redact_annot(r)
                page.apply_redactions(
                    images=pymupdf.PDF_REDACT_IMAGE_NONE,
                    graphics=pymupdf.PDF_REDACT_LINE_ART_NONE,
                )
            except Exception:
                pass
        self.redacted.add(pno)

    def place_plate(self, pno, block):
        self.finish_page()
        self._clean_src_page(pno, [block], self._pars_td_cache.get(pno, []))
        page = self.src[pno]
        pix = page.get_pixmap(clip=block, dpi=IMG_DPI)
        W, H = page.rect.width, page.rect.height
        plate = self.out.new_page(width=W, height=H)
        self.count += 1
        m = 16.0
        aw, ah = W - 2 * m, H - 2 * m
        scale = min(aw / block.width, ah / block.height, 1.0)
        w, h = block.width * scale, block.height * scale
        target = pymupdf.Rect(
            (W - w) / 2, (H - h) / 2, (W + w) / 2, (H + h) / 2
        )
        try:
            stream = pix.tobytes(output="jpeg", jpg_quality=85)
            plate.insert_image(target, stream=stream)
        except Exception:
            plate.insert_image(target, pixmap=pix)
        if pno not in self.first_out:
            self.first_out[pno] = len(self.out)

    def place_inline_image(self, pno, block):
        self.mark_origin(pno)
        self.ensure_page(pno)
        self.text_started.add(pno)
        w = min(self.width, block.width)
        h = block.height * (w / block.width)
        max_h = 0.62 * (self.bottom - self.top)
        if h > max_h:  # too tall to be inline after all
            self.place_plate(pno, block)
            return
        if self.remaining() < h + 14 and self.y > self.top + 0.5:
            self.finish_page()
            self.new_page(pno)
        self._clean_src_page(pno, [block], self._pars_td_cache.get(pno, []))
        pix = self.src[pno].get_pixmap(clip=block, dpi=INLINE_DPI)
        target = pymupdf.Rect(self.left, self.y, self.left + w, self.y + h)
        try:
            stream = pix.tobytes(output="jpeg", jpg_quality=85)
            self.page.insert_image(target, stream=stream)
        except Exception:
            self.page.insert_image(target, pixmap=pix)
        self.text_started.add(pno)
        self.y += h + 14


def compute_stats(pages, doc):
    sizes, lefts, rights = [], [], []
    tops, bottoms = [], []
    page_sizes = Counter()
    for p in doc:
        page_sizes[(round(p.rect.width), round(p.rect.height))] += 1
    (pw, ph), _ = page_sizes.most_common(1)[0]
    for pg in pages:
        rect = doc[pg["pageid"]].rect
        if abs(rect.width - pw) > 2 or abs(rect.height - ph) > 2:
            continue
        text_pars = [
            q
            for q in pg["paragraphs"]
            if letters(q["trans"] or q["text"]) >= 20 and q["cls"] >= 2
        ]
        if not text_pars:
            continue
        for q in text_pars:
            sizes.append(q["size"])
            lefts.append(q["x0"])
            rights.append(q["x1"])
        tops.append(rect.height - max(q["y1"] for q in text_pars))
        bottoms.append(rect.height - min(q["y0"] for q in text_pars))
    body = median(sizes) if sizes else 11.0
    left = median(lefts) if lefts else 54.0
    right = median(rights) if rights else pw - 54.0
    if right - left < 150:
        left, right = 54.0, pw - 54.0
    top = median(tops) if tops else 64.0
    top = max(46.0, min(top, 110.0))
    if bottoms:
        gap_bottom = max(46.0, min(ph - median(bottoms), 110.0))
    else:
        gap_bottom = 64.0
    bottom = ph - gap_bottom
    if bottom - top < 240:
        bottom = ph - 46.0
        if bottom - top < 240:
            top = 46.0
    return {
        "page_size": (pw, ph),
        "content": (left, right),
        "top": top,
        "bottom": bottom,
        "body": body,
    }


def is_scene_break(text):
    """A lone punctuation glyph (or two) acting as a scene separator."""
    t = text.strip()
    if not t or len(t) > 4:
        return False
    if letters(t) or digits(t):
        return False
    return bool(re.match(r"^[\u2022\u25cf\u25aa\u25e6\u00b7*\-–—⁂| .]+$", t))


def split_line_list(item, right_edge):
    """Split a merged list/TOC block back into one entry per source line.

    Returns a list of entry dicts, or None when the block does not look
    like a line list (or the entries cannot be recovered).
    """
    size = item["size"]
    height = item["bot"] - item["top"]
    if height < 1.7 * size:
        return None
    if item["x1"] > right_edge - LINELIST_MARGIN * size:
        return None
    raw = item.get("raw", "")
    segs = [s.strip(" .|") for s in re.split(r"\s{2,}", raw)]
    segs = [s for s in segs if letters(s) >= 2]
    if len(segs) < 2:
        return None
    # sanity: the vertical span must be able to hold that many lines
    max_lines = int(height / (size * 0.85)) + 1
    if len(segs) > max_lines:
        return None
    entries = []
    for seg in segs:
        fr = translate_line(seg)
        if not fr:
            return None  # cannot translate per-line: keep the whole block
        entries.append(
            {
                "kind": "text",
                "top": item["top"],
                "text": sanitize(fr),
                "raw": seg,
                "size": size,
                "font": item["font"],
                "indent": False,
                "heading": False,
                "centered": False,
                "justify": False,
                "entry": True,
                "origin": item["origin"],
                "trans": True,
                "x0": item["x0"],
                "x1": item["x1"],
                "bot": item["bot"],
            }
        )
    return entries


def can_merge_sentences(a, b, body):
    """True when block b is the continuation of a sentence ending in a."""
    if a["heading"] or b["heading"]:
        return False
    if a.get("entry") or b.get("entry"):
        return False
    if a["kind"] != "text" or b["kind"] != "text":
        return False
    if abs(a["size"] - b["size"]) > 0.18 * body:
        return False
    ta, tb = a["text"].strip(), b["text"].strip()
    if not ta or not tb:
        return False
    # refuse only when BOTH the translation and the source EN end with
    # terminal punctuation — translators often add a spurious period to
    # a fragment whose source continues on the next block
    if ends_sentence(ta) and ends_sentence(a.get("raw", ta)):
        return False
    if tb[0] in "«“—–-•*\u2022":
        return False
    if b["centered"] or a.get("centered"):
        return False
    # b continues a's sentence: starts lowercase, or a ends on a function word
    if not (tb[0].islower() or last_word(ta) in FUNCT_WORDS):
        return False
    if a["origin"] == b["origin"]:
        # same page: only merge when the blocks are vertically adjacent
        # (same text flow), not across a real paragraph break
        gap = b["top"] - a["bot"]
        if gap > 0.75 * a["size"]:
            return False
    return True


def build_items(pages, doc, blocks_by_page, stats):
    """Return {pageid: [items]} in reading order plus running-head info."""
    npages = len(pages)
    left_edge = stats["content"][0]
    head_candidates = Counter()
    page_texts = {}
    # first pass: gather geometry + margin candidates
    for pg in pages:
        pid = pg["pageid"]
        rect = doc[pid].rect
        blocks = blocks_by_page[pid]
        pars = []
        for q in pg["paragraphs"]:
            text = sanitize(q["trans"] or q["text"])
            if not text:
                continue
            x0 = rect.x0 + q["x0"]
            x1 = rect.x0 + q["x1"]
            top = rect.y0 + (rect.height - q["y1"])
            bot = rect.y0 + (rect.height - q["y0"])
            cx = (x0 + x1) / 2
            cy = (top + bot) / 2
            inside_img = any(
                b.x0 - 2 <= cx <= b.x1 + 2 and b.y0 - 2 <= cy <= b.y1 + 2
                for b in blocks
            )
            if inside_img and q["trans"] is None:
                continue  # art-internal text (kept only inside the bitmap)
            pars.append(
                {
                    "text": text,
                    # raw EN keeps its multi-space line joins (used to
                    # split merged TOC/list blocks back into entries)
                    "raw": q["text"],
                    "origin": pid,
                    "x0": x0,
                    "x1": x1,
                    "top": top,
                    "bot": bot,
                    "size": q["size"],
                    "font": q["font"],
                    "cls": q["cls"],
                    # dialogue paragraphs (opening guillemet) keep the
                    # v1 treatment: no first-line indent, so the normal
                    # paragraph gap separates consecutive speaker turns
                    "indent": not text.startswith(("«", "“", '"')) and (
                        (q["x"] - q["x0"]) > 0.4 * q["size"]
                        or (
                            0.35 * q["size"]
                            < q["x0"] - left_edge
                            < 2.5 * q["size"]
                            and letters(text) >= 15
                        )
                    ),
                    "trans": q["trans"] is not None,
                }
            )
        page_texts[pid] = pars

    # running heads / page numbers
    for pid, pars in page_texts.items():
        H = doc[pid].rect.height
        for p in pars:
            if len(p["text"]) <= 90 and (
                p["top"] < H * 0.10 or p["bot"] > H * 0.90
            ):
                if PAGENUM_RE.match(p["text"]):
                    p["drop"] = True
                else:
                    head_candidates[
                        re.sub(r"\d+", "#", p["text"].lower())
                    ] += 1
    threshold = max(4, int(npages * 0.15))
    for pid, pars in page_texts.items():
        H = doc[pid].rect.height
        for p in pars:
            if p.get("drop"):
                continue
            if len(p["text"]) <= 90 and (
                p["top"] < H * 0.10 or p["bot"] > H * 0.90
            ):
                key = re.sub(r"\d+", "#", p["text"].lower())
                if head_candidates[key] >= threshold and letters(p["text"]) > 0:
                    p["drop"] = True

    # dropcap merge + final items
    items_by_page = {}
    body = compute_body(page_texts)
    right_edge = stats["content"][1]
    for pid, pars in page_texts.items():
        pars = [p for p in pars if not p.get("drop")]
        pars.sort(key=lambda p: (p["top"], p["x0"]))
        # merge a large single leading letter into the next paragraph
        merged = []
        i = 0
        while i < len(pars):
            p = pars[i]
            if (
                i + 1 < len(pars)
                and letters(p["text"]) <= 2
                and p["size"] >= 1.4 * body
                and abs(pars[i + 1]["top"] - p["bot"]) < 2.2 * p["size"]
            ):
                nxt = pars[i + 1]
                nxt = dict(nxt)
                nxt["text"] = (p["text"] + nxt["text"]).strip()
                merged.append(nxt)
                i += 2
            else:
                merged.append(p)
                i += 1
        # mark scene separators (lone glyphs like ●, *, —)
        for p in merged:
            p["scene"] = is_scene_break(p["text"])

        # a lone glyph sitting tightly above a paragraph is that paragraph's
        # bullet, not a scene break: attach it to the paragraph's text
        bullet_idx = set()
        for i, p in enumerate(merged):
            if not p.get("scene") or i in bullet_idx:
                continue
            single_line = (p["bot"] - p["top"]) <= 1.6 * p["size"]
            if not single_line:
                continue
            j = next(
                (k for k in range(i + 1, len(merged))
                 if not merged[k].get("scene")),
                None,
            )
            if j is None:
                continue
            nxt = merged[j]
            if 0 <= nxt["top"] - p["bot"] <= 1.1 * p["size"]:
                nxt["text"] = "\u2022 " + nxt["text"].lstrip()
                bullet_idx.add(i)

        items = [p for k, p in enumerate(merged) if k not in bullet_idx]

        final = []
        for p in items:
            if p.get("scene"):
                final.append(
                    {
                        "kind": "scene",
                        "top": p["top"],
                        "text": p["text"],
                        "size": p["size"],
                        "font": p["font"],
                        "origin": p["origin"],
                        "x0": p["x0"],
                        "bot": p["bot"],
                    }
                )
                continue
            ratio = p["size"] / body if body else 1
            caps = (
                p["text"] == p["text"].upper()
                and letters(p["text"]) >= 3
                and ratio >= 1.05
            )
            heading = ratio >= 1.22 or (caps and ratio >= 1.05)
            base = {
                "kind": "text",
                "top": p["top"],
                "text": p["text"],
                "raw": p.get("raw", p["text"]),
                "size": p["size"],
                "font": p["font"],
                "indent": p["indent"],
                "heading": heading,
                "centered": heading
                and abs(
                    (p["x0"] + p["x1"]) / 2
                    - (doc[pid].rect.x0 + doc[pid].rect.width / 2)
                )
                < 45,
                "justify": not heading,
                "origin": p["origin"],
                "trans": p["trans"],
                "x0": p["x0"],
                "x1": p["x1"],
                "bot": p["bot"],
            }
            # TOC / list block merged by the layout model: split per line
            entries = None
            if not heading and p["trans"]:
                try:
                    entries = split_line_list(base, right_edge)
                except Exception:
                    entries = None
            if entries:
                final.extend(entries)
            else:
                final.append(base)
        # image items interleaved by vertical position
        for b in blocks_by_page[pid]:
            area_ratio = b.get_area() / doc[pid].rect.get_area()
            final.append(
                {
                    "kind": "plate" if area_ratio >= PLATE_RATIO else "image",
                    "rect": (b.x0, b.y0, b.x1, b.y1),
                    "top": b.y0,
                    "origin": pid,
                }
            )
        final.sort(key=lambda it: (it["top"], it.get("x0", 0)))
        items_by_page[pid] = final

    # re-join sentences split across two blocks or two pages
    join_items(items_by_page, body)
    return items_by_page, body


def join_items(items_by_page, body):
    """Merge continuation blocks: a sentence cut in two by the layout
    model or by a page boundary becomes one flowing item again."""
    prev_text = None  # last text item of the previous page, if unobstructed
    for pid in sorted(items_by_page):
        items = items_by_page[pid]
        out = []
        for it in items:
            if it["kind"] != "text":
                out.append(it)
                continue
            if out:
                # only the immediately preceding item can be a candidate
                cand = out[-1] if out[-1]["kind"] == "text" else None
            else:
                cand = prev_text  # first item of the page
            if cand is not None and can_merge_sentences(cand, it, body):
                # absorb b into a; drop the translation's spurious
                # trailing period when the source EN continues
                a_text = cand["text"].rstrip()
                if not ends_sentence(cand.get("raw", a_text)):
                    a_text = re.sub(r"[.!?…]\s*$", "", a_text)
                cand["text"] = a_text + " " + it["text"].lstrip()
                cand["raw"] = cand.get("raw", "").rstrip() + " " + it.get("raw", "")
                cand["bot"] = max(cand["bot"], it["bot"])
                cand["x1"] = max(cand["x1"], it["x1"])
                continue
            out.append(it)
        # the page's last item is a merge candidate only if it is text
        prev_text = out[-1] if out and out[-1]["kind"] == "text" else None
        items_by_page[pid] = out


def compute_body(page_texts):
    sizes = [
        p["size"]
        for pars in page_texts.values()
        for p in pars
        if letters(p["text"]) >= 20
    ]
    return median(sizes) if sizes else 11.0


def main(argv):
    global FONTS, TRANSLATOR, HYPH
    args = [a for a in argv[1:]]
    lang_in, lang_out = "en", "fr"
    json_paths = []
    i = 0
    while i < len(args):
        if args[i] == "--li" and i + 1 < len(args):
            lang_in = args[i + 1]
            i += 2
        elif args[i] == "--lo" and i + 1 < len(args):
            lang_out = args[i + 1]
            i += 2
        else:
            json_paths.append(args[i])
            i += 1
    if len(json_paths) < 3:
        print(
            "usage: flow_compose.py <source.pdf> <output.pdf> "
            "[--li en] [--lo fr] <flow.json> [more.json ...]",
            file=sys.stderr,
        )
        return 2
    src_path, out_path = json_paths[0], json_paths[1]
    json_paths = json_paths[2:]
    FONTS = build_fonts()
    TRANSLATOR = make_translator(lang_in, lang_out)
    HYPH = make_hyphenator(lang_out)

    pages = load_pages(json_paths)
    doc = pymupdf.open(src_path)
    blocks_by_page = {i: image_blocks(p) for i, p in enumerate(doc)}
    stats = compute_stats(pages, doc)
    items_by_page, body = build_items(pages, doc, blocks_by_page, stats)

    # geometry cache for redaction
    pars_td_cache = {}
    for pid, items in items_by_page.items():
        cache = [
            (it["x0"], it["x1"], it["top"], it["bot"], it.get("trans", False))
            for it in items
            if it["kind"] == "text"
        ]
        pars_td_cache[pid] = cache

    out = pymupdf.open()
    flow = FlowBook(doc, out, pages, stats)
    flow._pars_td_cache = pars_td_cache

    total = len(items_by_page)
    done = 0
    n_text = n_plates = 0
    for pid in sorted(items_by_page):
        items = items_by_page[pid]
        # plates flush the current page; process items in order
        for it in items:
            if it["kind"] == "scene":
                flow.mark_origin(pid)
                flow.place_scene_break(it)
            elif it["kind"] == "text":
                if not it["text"].strip():
                    continue
                flow.mark_origin(pid)
                if it["centered"]:
                    flow.place_centered(it)
                else:
                    flow.place_text(it)
                n_text += 1
            else:
                r = it["rect"]
                block = pymupdf.Rect(r)
                if it["kind"] == "plate":
                    flow.place_plate(pid, block)
                    n_plates += 1
                else:
                    flow.place_inline_image(pid, block)
        done += 1
        if done % 25 == 0 or done == total:
            print(f"COMPOSE {done}/{total}", flush=True)

    flow.finish_page()

    if out.page_count == 0:
        print(
            "ERROR: no content found — the PDF may be scanned "
            "(no text layer)",
            file=sys.stderr,
        )
        return 3

    # remap the table of contents onto the new pagination
    try:
        toc = doc.get_toc()
        if toc and flow.first_out:
            keys = sorted(flow.first_out)

            def mp(p):
                i = bisect_left(keys, p)
                if i < len(keys):
                    return flow.first_out[keys[i]]
                return flow.first_out[keys[-1]]

            out.set_toc([[lvl, t, mp(p)] for lvl, t, p in toc])
    except Exception:
        pass

    try:
        meta = doc.metadata or {}
        out.set_metadata(
            {
                "title": (meta.get("title") or "Livre") + " — Babelivre (FR)",
                "author": meta.get("author") or "",
                "creator": "Babelivre",
                "producer": "Babelivre",
            }
        )
    except Exception:
        pass

    out.save(out_path, deflate=True, garbage=4)
    print(
        f"DONE pages_in={len(items_by_page)} pages_out={out.page_count} "
        f"paragraphs={n_text} plates={n_plates}",
        flush=True,
    )
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
