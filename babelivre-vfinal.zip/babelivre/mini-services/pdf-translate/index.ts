/**
 * Babelivre translation service.
 * Receives PDF uploads, runs the chunked pdf2zh pipeline + flow composer,
 * exposes job status / download endpoints. One job at a time (4 GB RAM host).
 */
import { mkdir, readdir, rm, stat, writeFile } from "node:fs/promises";
import { existsSync, readFileSync } from "node:fs";
import path from "node:path";
import { $, spawn } from "bun";

const PORT = 3050;
const ROOT = import.meta.dir;
const JOBS_DIR = path.join(ROOT, "jobs");
const MAX_AGE_MS = 2 * 60 * 60 * 1000; // 2h
const MAX_UPLOAD = 60 * 1024 * 1024; // 60 MB

type Job = {
  id: string;
  status: "queued" | "processing" | "done" | "error";
  progress: number; // 0..100
  pages: { done: number; total: number };
  error?: string;
  createdAt: number;
  fileName: string;
};

const jobs = new Map<string, Job>();
const queue: string[] = [];
let running = false;

await mkdir(JOBS_DIR, { recursive: true });

/* ---------------------------------- errors --------------------------------- */

function friendlyError(raw: string): string {
  const s = raw.toLowerCase();
  if (
    s.includes("no content found") ||
    (s.includes("scann") && s.includes("texte")) ||
    (s.includes("no text layer"))
  )
    return "Ce PDF semble scanné (aucune couche de texte extractible). Les livres numériques avec du texte sélectionnable fonctionnent le mieux.";
  if (s.includes("password") || s.includes("encrypted") || s.includes("mot de passe"))
    return "Ce PDF est protégé par mot de passe. Retirez la protection puis réessayez.";
  if (
    s.includes("impossible de lancer") ||
    s.includes("invalid pdf") ||
    s.includes("cannot open") ||
    s.includes("fichier pdf invalide") ||
    s.includes("not a pdf") ||
    s.includes("format error")
  )
    return "Fichier PDF invalide ou corrompu. Vérifiez le fichier puis réessayez.";
  if (s.includes("erreur de memoire") || s.includes("oom"))
    return "Mémoire insuffisante pour ce PDF, même après découpage. Essayez un fichier plus léger.";
  if (
    s.includes("timed out") ||
    s.includes("timeout") ||
    s.includes("temporairement") ||
    s.includes("temporarily") ||
    s.includes("connection") ||
    s.includes("network") ||
    s.includes("503") ||
    s.includes("429")
  )
    return "Le service de traduction est momentanément indisponible (réseau saturé). Réessayez dans quelques minutes.";
  if (s.includes("unsupported translation service"))
    return "Service de traduction indisponible. Réessayez dans quelques minutes.";
  return "Une erreur inattendue est survenue pendant la traduction. Réessayez, ou avec un autre PDF.";
}

/* ------------------------------- job runner -------------------------------- */

function jobDir(id: string) {
  return path.join(JOBS_DIR, id);
}

function setJob(id: string, patch: Partial<Job>) {
  const j = jobs.get(id);
  if (!j) return;
  Object.assign(j, patch);
  persist(id);
}

function persist(id: string) {
  const j = jobs.get(id);
  if (!j) return;
  try {
    writeFile(
      path.join(jobDir(id), "meta.json"),
      JSON.stringify(j),
    ).catch(() => {});
  } catch {
    /* ignore */
  }
}

async function runJob(id: string) {
  const dir = jobDir(id);
  const outDir = path.join(dir, "out");
  await mkdir(outDir, { recursive: true });
  setJob(id, { status: "processing", progress: 1 });
  const t0 = Date.now();

  const proc = spawn(
    [
      path.join(ROOT, "venv", "bin", "python"),
      path.join(ROOT, "translate_job.py"),
      path.join(dir, "input.pdf"),
      outDir,
      "--pdf2zh",
      "./venv/bin/pdf2zh",
      "-li",
      "en",
      "-lo",
      "fr",
      "-s",
      "google",
      "-t",
      "4",
      "--chunk-pages",
      "50",
    ],
    {
      cwd: ROOT,
      stdout: "pipe",
      stderr: "pipe",
    },
  );

  let stderrTail = "";
  const readErr = async () => {
    const reader = proc.stderr.getReader();
    const dec = new TextDecoder();
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      stderrTail = (stderrTail + dec.decode(value)).slice(-4000);
    }
  };
  void readErr();

  const reader = proc.stdout.getReader();
  const dec = new TextDecoder();
  let buf = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    const lines = buf.split("\n");
    buf = lines.pop() ?? "";
    for (const line of lines) {
      handleLine(id, line.trim());
    }
  }
  if (buf.trim()) handleLine(id, buf.trim());

  const code = await proc.exited;
  const monoPath = path.join(outDir, "mono.pdf");
  if (code === 0 && existsSync(monoPath)) {
    setJob(id, { status: "done", progress: 100 });
    console.log(`[job ${id}] done in ${((Date.now() - t0) / 1000) | 0}s`);
  } else {
    setJob(id, {
      status: "error",
      error: friendlyError(stderrTail || `exit code ${code}`),
    });
    console.log(`[job ${id}] FAILED code=${code}: ${stderrTail.slice(-400)}`);
  }
}

function handleLine(id: string, line: string) {
  if (line.startsWith("PROGRESS ")) {
    const m = line.match(/^PROGRESS (\d+) (\d+)$/);
    if (m) {
      const done = parseInt(m[1], 10);
      const total = parseInt(m[2], 10);
      const frac = total > 0 ? done / total : 0;
      setJob(id, {
        progress: Math.max(1, Math.min(97, Math.round(frac * 97))),
        pages: { done, total },
      });
    }
  } else if (line === "PHASE compose") {
    setJob(id, { progress: 98 });
  }
}

async function pump() {
  if (running) return;
  const next = queue.shift();
  if (!next) return;
  running = true;
  try {
    await runJob(next);
  } catch (e) {
    setJob(next, {
      status: "error",
      error: friendlyError(String(e)),
    });
  } finally {
    running = false;
    void pump();
  }
}

/* --------------------------------- cleanup --------------------------------- */

async function cleanup() {
  try {
    for (const id of await readdir(JOBS_DIR)) {
      const dir = path.join(JOBS_DIR, id);
      const st = await stat(dir);
      if (Date.now() - st.mtimeMs > MAX_AGE_MS) {
        await rm(dir, { recursive: true, force: true });
        jobs.delete(id);
      }
    }
  } catch {
    /* ignore */
  }
}
setInterval(cleanup, 10 * 60 * 1000).unref?.();
void cleanup();

/* ---------------------------------- server --------------------------------- */

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json" },
  });
}

const server = Bun.serve({
  port: PORT,
  async fetch(req) {
    const url = new URL(req.url);

    if (req.method === "GET" && url.pathname === "/api/health") {
      return json({ ok: true, service: "babelivre", version: 2 });
    }

    if (req.method === "POST" && url.pathname === "/api/translate") {
      const form = await req.formData().catch(() => null);
      if (!form) return json({ error: "Requête invalide" }, 400);
      const file = form.get("file");
      if (!(file instanceof File))
        return json({ error: "Aucun fichier reçu" }, 400);
      if (file.size === 0) return json({ error: "Fichier vide" }, 400);
      if (file.size > MAX_UPLOAD)
        return json({ error: "Fichier trop volumineux (max 60 Mo)" }, 413);
      const name = file.name || "livre.pdf";
      if (!name.toLowerCase().endsWith(".pdf"))
        return json({ error: "Seuls les fichiers PDF sont acceptés" }, 400);

      const id = crypto.randomUUID().slice(0, 8);
      const dir = jobDir(id);
      await mkdir(dir, { recursive: true });
      await Bun.write(path.join(dir, "input.pdf"), file);

      const job: Job = {
        id,
        status: "queued",
        progress: 0,
        pages: { done: 0, total: 0 },
        createdAt: Date.now(),
        fileName: name,
      };
      jobs.set(id, job);
      queue.push(id);
      persist(id);
      void pump();
      return json({ jobId: id });
    }

    if (req.method === "GET" && url.pathname === "/api/status") {
      const id = url.searchParams.get("jobId") || "";
      const job = jobs.get(id);
      if (!job) return json({ error: "Job inconnu" }, 404);
      const mono = existsSync(path.join(jobDir(id), "out", "mono.pdf"));
      return json({
        status: job.status,
        progress: job.progress,
        pages: job.pages,
        hasMono: mono,
        hasDual: false,
        error: job.error,
      });
    }

    const fileRoute =
      (url.pathname === "/api/download" || url.pathname === "/api/preview") &&
      req.method === "GET";
    if (fileRoute) {
      const id = url.searchParams.get("jobId") || "";
      const type = url.searchParams.get("type") || "mono";
      const job = jobs.get(id);
      if (!job) return json({ error: "Job inconnu" }, 404);
      if (job.status !== "done")
        return json({ error: "Traduction non terminée" }, 409);
      if (type === "dual")
        return json({ error: "Version bilingue non disponible" }, 404);
      const p = path.join(jobDir(id), "out", "mono.pdf");
      if (!existsSync(p)) return json({ error: "Fichier absent" }, 404);
      const data = readFileSync(p);
      const inline = url.pathname === "/api/preview";
      const safeName = (job.fileName || "livre.pdf").replace(
        /[/\\?%*:|"<>]/g,
        "-",
      );
      const outName = safeName.replace(/\.pdf$/i, "") + " (français).pdf";
      return new Response(new Uint8Array(data), {
        headers: {
          "content-type": "application/pdf",
          ...(inline
            ? {}
            : {
                "content-disposition": `attachment; filename="${outName}"; filename*=UTF-8''${encodeURIComponent(outName)}`,
              }),
        },
      });
    }

    return json({ error: "Route inconnue" }, 404);
  },
});

console.log(`[babelivre] service listening on :${PORT}`);
export default server;
