#!/usr/bin/env python3
"""Babelivre translation job orchestrator.

Splits a PDF into page chunks, runs a patched pdf2zh per chunk (flow mode:
translated layout is serialized as JSON instead of being composed in place),
then re-typesets the whole book with the continuous-flow composer.

Progress protocol (stdout, one line each):
    PROGRESS <done_pages> <total_pages>
    PHASE compose
    DONE pages_in=<n> pages_out=<m> ...
Errors go to stderr with a non-zero exit code.

Memory safety: chunks run in separate processes; a chunk killed by the OOM
killer (-9 / 137) is retried recursively split in half, down to single pages.
"""

import argparse
import os
import re
import shutil
import subprocess
import sys
import tempfile

import pymupdf

# default pdf2zh formula-font regex WITHOUT ".*Ital": italic body text is
# real content in novels and must be translated
VFONT = (
    "(CM[^R]|MS.M|XY|MT|BL|RM|EU|LA|RS|LINE|LCIRCLE|TeX-|rsfs|txsy|wasy|"
    "stmary|.*Mono|.*Code|.*Sym|.*Math)"
)

OOM_CODES = {-9, 137}
MIN_CHUNK = 4


def emit(line):
    print(line, flush=True)


def page_count(pdf_path):
    doc = pymupdf.open(pdf_path)
    n = doc.page_count
    doc.close()
    return n


def run_chunk(pdf2zh_bin, pdf_path, first, last, lang_in, lang_out, service,
              threads, json_out, scratch, base_done, total_pages, depth=0):
    """Run pdf2zh on pages [first, last] (0-based, inclusive).

    Returns True on success. Splits in half and retries on OOM kills.
    """
    n = last - first + 1
    env = dict(os.environ)
    env["BABELIVRE_FLOW"] = "1"
    env["BABELIVRE_FLOW_OUT"] = json_out
    env["BABELIVRE_KEEP_INPUT"] = "1"
    cmd = [
        pdf2zh_bin,
        pdf_path,
        "-o", scratch,
        "--pages", f"{first + 1}-{last + 1}",
        "-li", lang_in,
        "-lo", lang_out,
        "-s", service,
        "-t", str(threads),
        "--vfont", VFONT,
    ]
    try:
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            env=env,
            cwd=scratch,
        )
    except OSError as e:
        print(f"impossible de lancer pdf2zh: {e}", file=sys.stderr)
        return False

    buf = ""
    last_done = 0
    tail = []
    while True:
        ch = proc.stdout.read(1)
        if not ch:
            break
        if ch in b"\r\n":
            line = buf
            buf = ""
            if line:
                tail.append(line)
                tail = tail[-40:]
                m = None
                for m2 in re.finditer(r"(\d+)/(\d+) \[", line):
                    m = m2
                if m:
                    try:
                        done = int(m.group(1))
                        chunk_total = int(m.group(2))
                        if 0 < done <= chunk_total:
                            last_done = done
                            emit(
                                f"PROGRESS {base_done + done} {total_pages}"
                            )
                    except ValueError:
                        pass
        else:
            buf += ch.decode("utf-8", "replace")
            if len(buf) > 10000:
                buf = buf[-2000:]
    proc.wait()
    rc = proc.returncode

    if rc == 0 and os.path.exists(json_out):
        return True

    if rc in OOM_CODES or rc < 0:
        # OOM kill: split this range and retry
        if n <= 1:
            print(
                "erreur de memoire (OOM) meme sur une seule page — "
                "document trop lourd",
                file=sys.stderr,
            )
            return False
        mid = (first + last) // 2
        emit(f"OOM retry pages {first + 1}-{last + 1} -> split")
        ok = run_chunk(
            pdf2zh_bin, pdf_path, first, mid, lang_in, lang_out, service,
            threads, json_out + f".a{depth}", scratch, base_done,
            total_pages, depth + 1,
        )
        if not ok:
            return False
        ok = run_chunk(
            pdf2zh_bin, pdf_path, mid + 1, last, lang_in, lang_out, service,
            threads, json_out + f".b{depth}", scratch,
            base_done + (mid - first + 1), total_pages, depth + 1,
        )
        return ok

    # any other failure: dump the tail for diagnosis
    print(
        "echec pdf2zh (code %s) pages %d-%d:\n%s"
        % (rc, first + 1, last + 1, "\n".join(tail[-25:])),
        file=sys.stderr,
    )
    return False


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("outdir")
    ap.add_argument("--pdf2zh", default="./venv/bin/pdf2zh")
    ap.add_argument("--composer", default=None)
    ap.add_argument("-li", default="en")
    ap.add_argument("-lo", default="fr")
    ap.add_argument("-s", default="google")
    ap.add_argument("-t", type=int, default=4)
    ap.add_argument("--chunk-pages", type=int, default=50)
    args = ap.parse_args()

    here = os.path.dirname(os.path.abspath(__file__))
    pdf2zh_bin = (
        args.pdf2zh if os.path.isabs(args.pdf2zh)
        else os.path.join(here, args.pdf2zh)
    )
    composer = args.composer or os.path.join(here, "flow_compose.py")

    os.makedirs(args.outdir, exist_ok=True)
    total = page_count(args.input)
    if total == 0:
        print("PDF sans pages", file=sys.stderr)
        return 1
    emit(f"PROGRESS 0 {total}")

    # pdf2zh deletes input files located under the system temp dir after the
    # first read — keep a stable copy outside /tmp for the chunk runs
    src = os.path.abspath(args.input)
    tmp_root = os.path.realpath(tempfile.gettempdir())
    if os.path.realpath(src).startswith(tmp_root + os.sep):
        stable = os.path.join(args.outdir, "_src.pdf")
        shutil.copy2(src, stable)
        src = stable

    scratch = tempfile.mkdtemp(prefix="babeljob-")
    jsons = []
    try:
        first = 0
        while first < total:
            last = min(first + args.chunk_pages - 1, total - 1)
            json_out = os.path.join(scratch, f"flow.{first}.json")
            ok = run_chunk(
                pdf2zh_bin, src, first, last,
                args.li, args.lo, args.s, args.t, json_out, scratch,
                first, total,
            )
            if not ok:
                return 2
            jsons.append(json_out)
            first = last + 1
    finally:
        pass

    emit("PHASE compose")
    out_pdf = os.path.join(args.outdir, "mono.pdf")
    cmd = [
        sys.executable, composer,
        src, out_pdf,
        "--li", args.li, "--lo", args.lo,
    ] + jsons
    proc = subprocess.run(cmd, capture_output=True, text=True)
    for line in proc.stdout.splitlines():
        if line.startswith(("COMPOSE", "DONE")):
            emit(line)
    if proc.returncode != 0:
        print(proc.stderr[-3000:], file=sys.stderr)
        return 3

    shutil.rmtree(scratch, ignore_errors=True)
    emit(f"PROGRESS {total} {total}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
