export const UPSTREAM_BASE = "http://127.0.0.1:3050";
