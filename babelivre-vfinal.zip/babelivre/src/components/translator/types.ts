export type TranslateStatus = "queued" | "processing" | "done" | "error";

export interface StatusPages {
  done: number;
  total: number;
}

export interface StatusResponse {
  status: TranslateStatus;
  progress: number; // 0-100
  pages?: StatusPages;
  hasMono?: boolean;
  hasDual?: boolean;
  error?: string;
}

export interface TranslateResponse {
  jobId: string;
}

export interface ApiError {
  error: string;
}

export const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50 Mo

export function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} o`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} Ko`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} Mo`;
}
