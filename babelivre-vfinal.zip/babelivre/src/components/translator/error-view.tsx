"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { AlertTriangle, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";

interface ErrorViewProps {
  message?: string;
  onRetry: () => void;
}

function friendlyMessage(message?: string): string {
  const raw = (message ?? "").toLowerCase();
  if (!raw) return "La traduction a échoué pour une raison inconnue. Veuillez réessayer.";
  if (raw.includes("scann") || raw.includes("ocr") || raw.includes("image")) {
    return "Ce PDF semble contenir des pages scannées (images) sans texte exploitable. Essayez un PDF textuel.";
  }
  if (raw.includes("password") || raw.includes("protég") || raw.includes("encrypted")) {
    return "Ce PDF est protégé par mot de passe et ne peut pas être traduit.";
  }
  if (raw.includes("corrupt") || raw.includes("invalide") || raw.includes("invalid") || raw.includes("parse")) {
    return "Le fichier PDF semble endommagé ou invalide.";
  }
  if (raw.includes("timeout") || raw.includes("délai")) {
    return "Le traitement a pris trop de temps. Réessayez, éventuellement avec un livre plus court.";
  }
  if (raw.includes("network") || raw.includes("réseau") || raw.includes("connect")) {
    return "Le service de traduction est momentanément injoignable. Veuillez réessayer dans un instant.";
  }
  return message as string;
}

export function ErrorView({ message, onRetry }: ErrorViewProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="flex flex-col gap-6"
      role="alert"
      aria-label="Erreur de traduction"
    >
      <div className="flex items-start gap-3">
        <AlertTriangle
          className="mt-0.5 h-6 w-6 shrink-0 text-red-600 dark:text-red-400"
          aria-hidden="true"
        />
        <div>
          <p className="font-semibold text-stone-900 dark:text-stone-100">
            La traduction a échoué
          </p>
          <p className="mt-1 text-sm text-stone-600 dark:text-stone-400">
            {friendlyMessage(message)}
          </p>
        </div>
      </div>

      <Button
        type="button"
        onClick={onRetry}
        className="h-12 w-full bg-amber-600 text-base font-semibold text-white hover:bg-amber-700"
      >
        <RotateCcw className="mr-2 h-4 w-4" aria-hidden="true" />
        Réessayer
      </Button>
    </motion.div>
  );
}
