"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { CheckCircle2, Download, Eye, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";

interface DoneViewProps {
  jobId: string;
  fileName: string;
  onReset: () => void;
}

export function DoneView({ jobId, fileName, onReset }: DoneViewProps) {
  // The preview embeds the full translated PDF, which can be heavy for
  // large books — only load it when the user asks for it.
  const [showPreview, setShowPreview] = React.useState(false);
  const downloadUrl = `/api/translate/download?jobId=${encodeURIComponent(
    jobId
  )}&type=mono`;
  const previewUrl = `/api/translate/preview?jobId=${encodeURIComponent(
    jobId
  )}&type=mono`;

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="flex flex-col gap-6"
      aria-label="Traduction terminée"
    >
      <div className="flex items-start gap-3">
        <CheckCircle2
          className="mt-0.5 h-6 w-6 shrink-0 text-amber-600 dark:text-amber-500"
          aria-hidden="true"
        />
        <div className="min-w-0">
          <p className="font-semibold text-stone-900 dark:text-stone-100">
            Votre livre est prêt
          </p>
          <p className="mt-1 break-words text-sm text-stone-500 dark:text-stone-400">
            « {fileName} » a été traduit en français.
          </p>
        </div>
      </div>

      <div className="flex flex-col gap-3 sm:flex-row">
        <Button
          asChild
          className="h-12 flex-1 bg-amber-600 text-base font-semibold text-white hover:bg-amber-700"
        >
          <a href={downloadUrl} download>
            <Download className="mr-2 h-5 w-5" aria-hidden="true" />
            Télécharger en français
          </a>
        </Button>
        <Button
          type="button"
          variant="outline"
          onClick={onReset}
          className="h-12 flex-1 border-stone-300 text-stone-700 hover:bg-stone-100 dark:border-stone-700 dark:text-stone-300 dark:hover:bg-stone-800"
        >
          <RotateCcw className="mr-2 h-4 w-4" aria-hidden="true" />
          Traduire un autre livre
        </Button>
      </div>

      <div className="rounded-lg border border-stone-200 bg-stone-50 p-4 text-sm text-stone-600 dark:border-stone-800 dark:bg-stone-900/60 dark:text-stone-400">
        Les pages sont remplies entièrement — la pagination peut différer de
        l'original, avec des marqueurs « suite de la page X ».
      </div>

      <div className="flex flex-col gap-2">
        {showPreview ? (
          <>
            <p className="text-sm font-medium text-stone-700 dark:text-stone-300">
              Aperçu du résultat
            </p>
            <div className="overflow-hidden rounded-lg border border-stone-200 dark:border-stone-800">
              <object
                data={previewUrl}
                type="application/pdf"
                aria-label="Aperçu du PDF traduit en français"
                className="h-[600px] max-h-[600px] w-full"
              >
                <iframe
                  src={previewUrl}
                  title="Aperçu du PDF traduit"
                  className="h-[600px] max-h-[600px] w-full"
                />
              </object>
            </div>
          </>
        ) : (
          <Button
            type="button"
            variant="outline"
            onClick={() => setShowPreview(true)}
            className="h-11 border-stone-300 text-stone-700 hover:bg-stone-100 dark:border-stone-700 dark:text-stone-300 dark:hover:bg-stone-800"
          >
            <Eye className="mr-2 h-4 w-4" aria-hidden="true" />
            Afficher l&apos;aperçu du résultat
          </Button>
        )}
      </div>
    </motion.div>
  );
}
