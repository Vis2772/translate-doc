"use client";

import * as React from "react";
import { motion } from "framer-motion";
import {
  ArrowRight,
  FileText,
  UploadCloud,
  X,
  Languages,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { MAX_FILE_SIZE, formatFileSize } from "./types";

interface UploadViewProps {
  onSubmitted: (jobId: string, fileName: string) => void;
}

export function UploadView({ onSubmitted }: UploadViewProps) {
  const { toast } = useToast();
  const inputRef = React.useRef<HTMLInputElement>(null);
  const [file, setFile] = React.useState<File | null>(null);
  const [dragging, setDragging] = React.useState(false);
  const [submitting, setSubmitting] = React.useState(false);

  const pickFile = React.useCallback(
    (candidate: File | null | undefined) => {
      if (!candidate) return;
      const isPdf =
        candidate.type === "application/pdf" ||
        candidate.name.toLowerCase().endsWith(".pdf");
      if (!isPdf) {
        toast({
          title: "Format non pris en charge",
          description: "Veuillez choisir un fichier PDF.",
          variant: "destructive",
        });
        return;
      }
      if (candidate.size > MAX_FILE_SIZE) {
        toast({
          title: "Fichier trop volumineux",
          description: "La taille maximale est de 50 Mo.",
          variant: "destructive",
        });
        return;
      }
      setFile(candidate);
    },
    [toast]
  );

  const handleDrop = React.useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setDragging(false);
      pickFile(e.dataTransfer.files?.[0]);
    },
    [pickFile]
  );

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!file || submitting) return;

    setSubmitting(true);
    try {
      const form = new FormData();
      form.append("file", file);
      form.append("sourceLang", "en");
      form.append("targetLang", "fr");

      const res = await fetch("/api/translate", { method: "POST", body: form });
      const data = (await res.json()) as { jobId?: string; error?: string };

      if (!res.ok || !data.jobId) {
        toast({
          title: "Échec de l'envoi",
          description:
            data.error ?? "Le service de traduction est indisponible pour le moment.",
          variant: "destructive",
        });
        return;
      }

      onSubmitted(data.jobId, file.name);
    } catch {
      toast({
        title: "Erreur réseau",
        description: "Impossible de contacter le serveur. Veuillez réessayer.",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <motion.form
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      onSubmit={handleSubmit}
      className="flex flex-col gap-6"
      aria-label="Envoyer un livre PDF à traduire"
    >
      {/* Zone de dépôt */}
      <div
        role="button"
        tabIndex={0}
        aria-label="Zone de dépôt de fichier PDF"
        onClick={() => inputRef.current?.click()}
        onKeyDown={(e) => {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            inputRef.current?.click();
          }
        }}
        onDragOver={(e) => {
          e.preventDefault();
          setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={handleDrop}
        className={cn(
          "flex min-h-44 cursor-pointer flex-col items-center justify-center gap-3 rounded-xl border-2 border-dashed p-6 text-center transition-colors",
          "border-stone-300 bg-stone-100/60 hover:border-amber-500 hover:bg-amber-50",
          "dark:border-stone-700 dark:bg-stone-900/40 dark:hover:border-amber-600 dark:hover:bg-stone-900",
          dragging && "border-amber-600 bg-amber-50 dark:bg-stone-900"
        )}
      >
        <div className="flex h-12 w-12 items-center justify-center rounded-full bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-400">
          <UploadCloud className="h-6 w-6" aria-hidden="true" />
        </div>
        <div>
          <p className="font-medium text-stone-900 dark:text-stone-100">
            Déposez votre livre PDF ici
          </p>
          <p className="mt-1 text-sm text-stone-500 dark:text-stone-400">
            ou cliquez pour parcourir vos fichiers · PDF · 50 Mo max
          </p>
        </div>
        <input
          ref={inputRef}
          type="file"
          accept=".pdf,application/pdf"
          className="sr-only"
          onChange={(e) => {
            pickFile(e.target.files?.[0]);
            e.target.value = "";
          }}
        />
      </div>

      {/* Fichier sélectionné */}
      {file && (
        <motion.div
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between gap-4 rounded-lg border border-stone-200 bg-stone-50 p-4 dark:border-stone-800 dark:bg-stone-900/60"
        >
          <div className="flex min-w-0 items-center gap-3">
            <FileText
              className="h-5 w-5 shrink-0 text-amber-700 dark:text-amber-400"
              aria-hidden="true"
            />
            <div className="min-w-0">
              <p className="truncate font-medium text-stone-900 dark:text-stone-100">
                {file.name}
              </p>
              <p className="text-sm text-stone-500 dark:text-stone-400">
                {formatFileSize(file.size)}
              </p>
            </div>
          </div>
          <Button
            type="button"
            variant="ghost"
            size="icon"
            aria-label="Retirer le fichier sélectionné"
            className="h-11 w-11 shrink-0"
            onClick={() => setFile(null)}
          >
            <X className="h-4 w-4" aria-hidden="true" />
          </Button>
        </motion.div>
      )}

      {/* Langues */}
      <div className="flex flex-wrap items-center justify-center gap-3">
        <Badge
          variant="outline"
          className="gap-1.5 border-stone-300 px-3 py-1.5 text-sm text-stone-700 dark:border-stone-600 dark:text-stone-300"
        >
          <Languages className="h-4 w-4 text-amber-700 dark:text-amber-400" aria-hidden="true" />
          Anglais
        </Badge>
        <ArrowRight
          className="h-4 w-4 text-stone-400"
          aria-label="vers"
        />
        <Badge
          variant="outline"
          className="gap-1.5 border-amber-300 bg-amber-50 px-3 py-1.5 text-sm text-amber-800 dark:border-amber-800 dark:bg-amber-950 dark:text-amber-300"
        >
          Français
        </Badge>
      </div>

      <Button
        type="submit"
        disabled={!file || submitting}
        className="h-12 w-full bg-amber-600 text-base font-semibold text-white hover:bg-amber-700 disabled:opacity-50"
      >
        {submitting ? (
          <>
            <span
              className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white"
              aria-hidden="true"
            />
            Envoi en cours…
          </>
        ) : (
          "Traduire en français"
        )}
      </Button>
    </motion.form>
  );
}
