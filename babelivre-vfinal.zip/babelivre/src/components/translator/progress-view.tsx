"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { FileText, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import type { StatusResponse } from "./types";

interface ProgressViewProps {
  jobId: string;
  fileName: string;
  status: StatusResponse | null;
  onCancel: () => void;
}

export function ProgressView({ jobId, fileName, status, onCancel }: ProgressViewProps) {
  const st = status?.status ?? "queued";
  const progress =
    typeof status?.progress === "number" && status.progress >= 0
      ? Math.min(100, Math.round(status.progress))
      : 0;

  let phaseText: string;
  if (st === "queued") {
    phaseText = "En attente…";
  } else if (st === "processing") {
    const pages = status?.pages;
    phaseText = pages
      ? `Traduction en cours… ${pages.done}/${pages.total} pages`
      : "Traduction en cours…";
  } else if (st === "done") {
    phaseText = "Terminé !";
  } else {
    phaseText = "Une erreur est survenue.";
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="flex flex-col gap-6"
      aria-label="Progression de la traduction"
      aria-live="polite"
    >
      <div className="flex items-center gap-3">
        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-400">
          {st === "done" ? (
            <FileText className="h-6 w-6" aria-hidden="true" />
          ) : (
            <Loader2 className="h-6 w-6 animate-spin" aria-hidden="true" />
          )}
        </div>
        <div className="min-w-0">
          <p className="truncate font-medium text-stone-900 dark:text-stone-100">
            {fileName}
          </p>
          <p className="text-sm text-stone-500 dark:text-stone-400">
            Identifiant : <span className="font-mono">{jobId}</span>
          </p>
        </div>
      </div>

      <div className="flex flex-col gap-2">
        <div className="flex items-baseline justify-between gap-4">
          <p className="font-medium text-stone-800 dark:text-stone-200">
            {phaseText}
          </p>
          <p className="text-sm tabular-nums text-stone-500 dark:text-stone-400">
            {progress} %
          </p>
        </div>
        <Progress
          value={progress}
          aria-label={`Progression : ${progress} %`}
          className="h-3 [&>div]:bg-amber-600"
        />
        {status?.pages && (
          <p className="text-sm text-stone-500 dark:text-stone-400">
            {status.pages.done} page{status.pages.done > 1 ? "s" : ""} sur{" "}
            {status.pages.total} traduite{status.pages.done > 1 ? "s" : ""}
          </p>
        )}
      </div>

      <Button
        type="button"
        variant="outline"
        onClick={onCancel}
        className="h-11 w-full border-stone-300 text-stone-700 hover:bg-stone-100 dark:border-stone-700 dark:text-stone-300 dark:hover:bg-stone-800"
      >
        Retour
      </Button>
    </motion.div>
  );
}
