"use client";

import * as React from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { UploadView } from "./upload-view";
import { ProgressView } from "./progress-view";
import { DoneView } from "./done-view";
import { ErrorView } from "./error-view";
import type { StatusResponse } from "./types";

type Phase =
  | { view: "upload" }
  | { view: "progress"; jobId: string; fileName: string }
  | { view: "done"; jobId: string; fileName: string }
  | { view: "error"; jobId: string; fileName: string; message?: string };

const POLL_INTERVAL_MS = 1500;

export function TranslatorApp() {
  const [phase, setPhase] = React.useState<Phase>({ view: "upload" });
  const [status, setStatus] = React.useState<StatusResponse | null>(null);

  // Stop polling whenever the phase leaves "progress".
  React.useEffect(() => {
    if (phase.view !== "progress") return;

    const jobId = phase.jobId;
    let cancelled = false;
    let timer: ReturnType<typeof setTimeout> | null = null;

    async function poll() {
      try {
        const res = await fetch(
          `/api/translate/status?jobId=${encodeURIComponent(jobId)}`,
          { cache: "no-store" }
        );
        const data = (await res.json()) as StatusResponse;
        if (cancelled) return;

        if (res.ok) {
          setStatus(data);
          if (data.status === "done") {
            setPhase((p) =>
              p.view === "progress"
                ? { view: "done", jobId, fileName: p.fileName }
                : p
            );
            return;
          }
          if (data.status === "error") {
            setPhase((p) =>
              p.view === "progress"
                ? { view: "error", jobId, fileName: p.fileName, message: data.error }
                : p
            );
            return;
          }
        }
      } catch {
        // Transient network error: keep polling.
      }

      if (!cancelled) {
        timer = setTimeout(poll, POLL_INTERVAL_MS);
      }
    }

    poll();

    return () => {
      cancelled = true;
      if (timer) clearTimeout(timer);
    };
  }, [phase.view === "progress" ? phase.jobId : null]);

  const reset = React.useCallback(() => {
    setStatus(null);
    setPhase({ view: "upload" });
  }, []);

  return (
    <Card className="mx-auto w-full max-w-2xl border-stone-200 bg-white/80 shadow-sm backdrop-blur dark:border-stone-800 dark:bg-stone-900/70">
      <CardHeader>
        <CardTitle className="text-xl text-stone-900 dark:text-stone-50">
          Traduire un livre
        </CardTitle>
        <CardDescription className="text-stone-500 dark:text-stone-400">
          Anglais vers français · mise en page naturelle, texte complet
        </CardDescription>
      </CardHeader>
      <CardContent>
        {phase.view === "upload" && (
          <UploadView
            onSubmitted={(jobId, fileName) => {
              setStatus(null);
              setPhase({ view: "progress", jobId, fileName });
            }}
          />
        )}

        {phase.view === "progress" && (
          <ProgressView
            jobId={phase.jobId}
            fileName={phase.fileName}
            status={status}
            onCancel={reset}
          />
        )}

        {phase.view === "done" && (
          <DoneView
            jobId={phase.jobId}
            fileName={phase.fileName}
            onReset={reset}
          />
        )}

        {phase.view === "error" && (
          <ErrorView message={phase.message} onRetry={reset} />
        )}
      </CardContent>
    </Card>
  );
}
