import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Babelivre — Traduction de livres PDF en français",
  description:
    "Traduisez gratuitement vos livres PDF de l'anglais vers le français. Texte complet (italiques inclus), mise en page naturelle, pages remplies sans gaspillage. 100 % gratuit, sans inscription.",
  keywords: [
    "traduction",
    "PDF",
    "anglais",
    "français",
    "livre",
    "gratuit",
    "Babelivre",
  ],
  openGraph: {
    title: "Babelivre — Traduction de livres PDF en français",
    description:
      "Traduisez vos livres anglais en français, gratuitement et sans inscription.",
    siteName: "Babelivre",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fr" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
