import { NextRequest, NextResponse } from "next/server";
import { UPSTREAM_BASE } from "@/lib/upstream";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";
export const maxDuration = 3600;

export async function POST(req: NextRequest) {
  try {
    let form: FormData;
    try {
      form = await req.formData();
    } catch {
      return NextResponse.json(
        { error: "Requête invalide : fichier PDF manquant." },
        { status: 400 }
      );
    }

    const file = form.get("file");
    if (!(file instanceof File)) {
      return NextResponse.json(
        { error: "Aucun fichier PDF reçu." },
        { status: 400 }
      );
    }

    // Rebuild FormData so blobs/files are forwarded correctly.
    const upstreamForm = new FormData();
    upstreamForm.append("file", file, file.name || "document.pdf");
    const sourceLang = form.get("sourceLang");
    const targetLang = form.get("targetLang");
    if (typeof sourceLang === "string" && sourceLang) {
      upstreamForm.append("sourceLang", sourceLang);
    }
    if (typeof targetLang === "string" && targetLang) {
      upstreamForm.append("targetLang", targetLang);
    }

    const res = await fetch(`${UPSTREAM_BASE}/api/translate`, {
      method: "POST",
      body: upstreamForm,
      cache: "no-store",
    });

    const text = await res.text();
    let json: unknown;
    try {
      json = JSON.parse(text);
    } catch {
      json = { error: "Réponse invalide du service de traduction." };
    }

    if (!res.ok) {
      const message =
        (json as { error?: string }).error ??
        "Le service de traduction a renvoyé une erreur.";
      return NextResponse.json({ error: message }, { status: res.status });
    }

    return NextResponse.json(json, { status: 200 });
  } catch {
    return NextResponse.json(
      { error: "Impossible de contacter le service de traduction." },
      { status: 502 }
    );
  }
}
