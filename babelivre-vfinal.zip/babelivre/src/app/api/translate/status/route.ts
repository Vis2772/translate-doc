import { NextRequest, NextResponse } from "next/server";
import { UPSTREAM_BASE } from "@/lib/upstream";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET(req: NextRequest) {
  const jobId = req.nextUrl.searchParams.get("jobId");
  if (!jobId) {
    return NextResponse.json({ error: "Paramètre jobId manquant." }, { status: 400 });
  }

  try {
    const res = await fetch(
      `${UPSTREAM_BASE}/api/status?jobId=${encodeURIComponent(jobId)}`,
      { cache: "no-store" }
    );

    const text = await res.text();
    let json: unknown;
    try {
      json = JSON.parse(text);
    } catch {
      json = { status: "error", error: "Réponse invalide du service." };
    }

    return NextResponse.json(json, { status: res.ok ? 200 : res.status });
  } catch {
    return NextResponse.json(
      { status: "error", error: "Impossible de contacter le service de traduction." },
      { status: 502 }
    );
  }
}
