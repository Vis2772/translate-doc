import { NextRequest, NextResponse } from "next/server";
import { UPSTREAM_BASE } from "@/lib/upstream";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

function sanitizeJobId(jobId: string): string {
  // Keep the id safe for use inside a filename.
  return jobId.replace(/[^a-zA-Z0-9_-]/g, "").slice(0, 64) || "job";
}

export async function GET(req: NextRequest) {
  const jobId = req.nextUrl.searchParams.get("jobId");
  const type = req.nextUrl.searchParams.get("type") ?? "mono";

  if (!jobId) {
    return NextResponse.json({ error: "Paramètre jobId manquant." }, { status: 400 });
  }
  if (type !== "mono" && type !== "dual") {
    return NextResponse.json(
      { error: "Type de téléchargement invalide." },
      { status: 400 }
    );
  }

  try {
    const upstreamUrl = `${UPSTREAM_BASE}/api/download?jobId=${encodeURIComponent(
      jobId
    )}&type=${encodeURIComponent(type)}`;

    const res = await fetch(upstreamUrl, { cache: "no-store" });

    if (!res.ok || !res.body) {
      return NextResponse.json(
        { error: "Fichier introuvable ou expiré." },
        { status: res.status === 404 ? 404 : 502 }
      );
    }

    const safeId = sanitizeJobId(jobId);
    const headers = new Headers();
    headers.set("Content-Type", "application/pdf");
    headers.set(
      "Content-Disposition",
      `attachment; filename="babelivre-${safeId}.pdf"`
    );
    const contentLength = res.headers.get("content-length");
    if (contentLength) headers.set("Content-Length", contentLength);

    return new NextResponse(res.body, { status: 200, headers });
  } catch {
    return NextResponse.json(
      { error: "Impossible de récupérer le fichier." },
      { status: 502 }
    );
  }
}
