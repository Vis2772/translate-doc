import { NextRequest, NextResponse } from "next/server";
import { UPSTREAM_BASE } from "@/lib/upstream";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET(req: NextRequest) {
  const jobId = req.nextUrl.searchParams.get("jobId");
  const type = req.nextUrl.searchParams.get("type") ?? "mono";

  if (!jobId) {
    return NextResponse.json({ error: "Paramètre jobId manquant." }, { status: 400 });
  }
  if (type !== "mono" && type !== "dual") {
    return NextResponse.json({ error: "Type d'aperçu invalide." }, { status: 400 });
  }

  try {
    const upstreamUrl = `${UPSTREAM_BASE}/api/download?jobId=${encodeURIComponent(
      jobId
    )}&type=${encodeURIComponent(type)}`;

    const res = await fetch(upstreamUrl, { cache: "no-store" });

    if (!res.ok || !res.body) {
      return NextResponse.json(
        { error: "Fichier introuvable ou expiré." },
        { status: res.status === 404 ? 404 : 502 }
      );
    }

    const headers = new Headers();
    headers.set("Content-Type", "application/pdf");
    headers.set("Content-Disposition", "inline");

    return new NextResponse(res.body, { status: 200, headers });
  } catch {
    return NextResponse.json(
      { error: "Impossible de récupérer l'aperçu." },
      { status: 502 }
    );
  }
}
