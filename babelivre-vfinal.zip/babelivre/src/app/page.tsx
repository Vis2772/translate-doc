import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import {
  BookOpen,
  BookOpenText,
  FileText,
  Layers,
  Lock,
  ScrollText,
  Sparkles,
  Zap,
} from "lucide-react";
import { TranslatorApp } from "@/components/translator/translator-app";

const features = [
  {
    icon: BookOpenText,
    title: "Texte complet",
    description:
      "Tout le contenu est traduit, y compris les passages en italique. Aucun fragment laissé de côté.",
  },
  {
    icon: Layers,
    title: "Écoulement intelligent",
    description:
      "Le texte s'étend librement, des pages s'ajoutent automatiquement si la traduction est plus longue, et chaque page est remplie : zéro espace blanc gâché.",
  },
  {
    icon: FileText,
    title: "Grands livres",
    description:
      "Découpage automatique en blocs pour traiter sans encombre les PDF de 300 pages et plus.",
  },
  {
    icon: Lock,
    title: "Gratuit et privé",
    description:
      "Aucune inscription requise. Vos fichiers sont supprimés après traitement.",
  },
];

const faq = [
  {
    question: "Quels types de PDF sont acceptés ?",
    answer:
      "Tous les PDF contenant du texte sélectionnable (romans, essais, manuels…), jusqu'à 50 Mo. Les PDF entièrement scannés en images ne peuvent pas être traduits, car ils ne contiennent pas de texte exploitable.",
  },
  {
    question: "Combien de temps prend une traduction ?",
    answer:
      "Cela dépend de la longueur du livre : quelques minutes pour un roman court, davantage pour un ouvrage de plusieurs centaines de pages. Le traitement est découpé automatiquement, ce qui permet de gérer les très grands livres sans interruption.",
  },
  {
    question: "Quelle est la qualité de la traduction ?",
    answer:
      "La traduction couvre l'intégralité du texte, italiques compris, et préserve la structure du livre. La mise en page est reconstruite en français : la pagination peut donc différer de l'original, avec des marqueurs « suite de la page X » lorsque le contenu continue sur la page suivante.",
  },
  {
    question: "Mes fichiers sont-ils conservés ?",
    answer:
      "Non. Aucune inscription n'est nécessaire et vos fichiers sont supprimés du serveur une fois la traduction terminée et téléchargée.",
  },
];

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col bg-stone-50 text-stone-900 dark:bg-stone-950 dark:text-stone-100">
      {/* En-tête */}
      <header className="sticky top-0 z-40 border-b border-stone-200 bg-stone-50/90 backdrop-blur dark:border-stone-800 dark:bg-stone-950/90">
        <div className="mx-auto flex h-16 w-full max-w-5xl items-center justify-between px-4 sm:px-6">
          <div className="flex items-center gap-2">
            <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-amber-600 text-white">
              <BookOpen className="h-5 w-5" aria-hidden="true" />
            </span>
            <span className="text-lg font-semibold tracking-tight">Babelivre</span>
          </div>
          <Badge
            variant="outline"
            className="border-amber-300 bg-amber-50 px-3 py-1 text-sm font-medium text-amber-800 dark:border-amber-800 dark:bg-amber-950 dark:text-amber-300"
          >
            Gratuit
          </Badge>
        </div>
      </header>

      <main className="flex-1">
        {/* Héros */}
        <section className="mx-auto w-full max-w-5xl px-4 pb-10 pt-12 sm:px-6 sm:pt-16">
          <div className="mx-auto flex max-w-2xl flex-col items-center gap-5 text-center">
            <h1 className="text-3xl font-bold tracking-tight text-stone-900 sm:text-4xl dark:text-stone-50">
              Traduisez vos livres anglais en{" "}
              <span className="text-amber-700 dark:text-amber-500">français</span>
            </h1>
            <p className="text-base leading-relaxed text-stone-600 sm:text-lg dark:text-stone-400">
              Une mise en page naturelle et un texte complet, italiques inclus.
              Le contenu s'écoule librement : des pages s'ajoutent si la
              traduction est plus longue, et chaque page est remplie — aucun
              espace blanc gâché.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-2">
              <Badge
                variant="outline"
                className="gap-1.5 border-stone-300 px-3 py-1.5 text-stone-700 dark:border-stone-600 dark:text-stone-300"
              >
                <BookOpenText className="h-4 w-4 text-amber-700 dark:text-amber-400" aria-hidden="true" />
                Texte complet
              </Badge>
              <Badge
                variant="outline"
                className="gap-1.5 border-stone-300 px-3 py-1.5 text-stone-700 dark:border-stone-600 dark:text-stone-300"
              >
                <Layers className="h-4 w-4 text-amber-700 dark:text-amber-400" aria-hidden="true" />
                Pages remplies
              </Badge>
              <Badge
                variant="outline"
                className="gap-1.5 border-stone-300 px-3 py-1.5 text-stone-700 dark:border-stone-600 dark:text-stone-300"
              >
                <Zap className="h-4 w-4 text-amber-700 dark:text-amber-400" aria-hidden="true" />
                Rapide
              </Badge>
            </div>
          </div>
        </section>

        {/* Traducteur */}
        <section className="mx-auto w-full max-w-5xl px-4 pb-14 sm:px-6" aria-label="Outil de traduction">
          <TranslatorApp />
        </section>

        {/* Fonctionnalités */}
        <section
          className="border-t border-stone-200 bg-white/60 py-14 dark:border-stone-800 dark:bg-stone-900/40"
          aria-label="Fonctionnalités"
        >
          <div className="mx-auto w-full max-w-5xl px-4 sm:px-6">
            <h2 className="mb-8 flex items-center gap-2 text-2xl font-semibold tracking-tight text-stone-900 dark:text-stone-50">
              <Sparkles className="h-5 w-5 text-amber-600 dark:text-amber-500" aria-hidden="true" />
              Pourquoi Babelivre ?
            </h2>
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {features.map((feature) => (
                <Card
                  key={feature.title}
                  className="border-stone-200 bg-white transition-shadow hover:shadow-md dark:border-stone-800 dark:bg-stone-900"
                >
                  <CardContent className="flex flex-col gap-3 p-6">
                    <span className="flex h-11 w-11 items-center justify-center rounded-lg bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-400">
                      <feature.icon className="h-5 w-5" aria-hidden="true" />
                    </span>
                    <h3 className="font-semibold text-stone-900 dark:text-stone-100">
                      {feature.title}
                    </h3>
                    <p className="text-sm leading-relaxed text-stone-600 dark:text-stone-400">
                      {feature.description}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* FAQ */}
        <section
          className="border-t border-stone-200 py-14 dark:border-stone-800"
          aria-label="Questions fréquentes"
        >
          <div className="mx-auto w-full max-w-3xl px-4 sm:px-6">
            <h2 className="mb-8 flex items-center gap-2 text-2xl font-semibold tracking-tight text-stone-900 dark:text-stone-50">
              <ScrollText className="h-5 w-5 text-amber-600 dark:text-amber-500" aria-hidden="true" />
              Questions fréquentes
            </h2>
            <Accordion type="single" collapsible className="w-full">
              {faq.map((item, index) => (
                <AccordionItem
                  key={index}
                  value={`faq-${index}`}
                  className="border-stone-200 dark:border-stone-800"
                >
                  <AccordionTrigger className="min-h-11 text-left text-base font-medium text-stone-900 hover:text-amber-700 hover:no-underline dark:text-stone-100 dark:hover:text-amber-400">
                    {item.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-sm leading-relaxed text-stone-600 dark:text-stone-400">
                    {item.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </section>
      </main>

      {/* Pied de page */}
      <footer className="mt-auto border-t border-stone-200 bg-stone-100/70 pb-[env(safe-area-inset-bottom)] dark:border-stone-800 dark:bg-stone-900/50">
        <div className="mx-auto flex w-full max-w-5xl flex-col items-center justify-between gap-2 px-4 py-6 text-sm text-stone-500 sm:flex-row sm:px-6 dark:text-stone-400">
          <p>Babelivre — Traduction libre de vos livres</p>
          <p>Gratuit, sans inscription</p>
        </div>
      </footer>
    </div>
  );
}
