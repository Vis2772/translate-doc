# Babelivre — Traducteur de livres PDF anglais → français

Application web gratuite de traduction de PDF (EN → FR) qui préserve la mise en page
du livre et recompose le texte traduit en **flux continu** : les pages sont remplies
jusqu'en bas, le texte peut se couper d'une page à l'autre, et les pages qui
commencent en plein milieu d'une page d'origine portent un marqueur discret
« — suite de la page N — ».

---

## Contenu de l'archive

```
babelivre/
├── src/                          # Application Next.js 16 (page unique /)
│   ├── app/                      # Pages + routes API (proxy vers le service)
│   └── components/translator/    # UI (thème papier/ambre, shadcn/ui)
├── mini-services/pdf-translate/  # Service Bun (port 3050) + jobs Python
│   ├── index.ts                  # File de jobs HTTP (health/status/download/preview)
│   ├── translate_job.py          # Découpage par blocs de 50 pages, fusion, OOM-safe
│   └── flow_compose.py           # ★ Recomposition en flux continu (pages pleines)
├── patches/                      # Fichiers Python patchés (à copier dans le venv)
│   ├── pdf2zh/                   # pdf2zh 1.9.11 patché (voir ci-dessous)
│   └── pymupdf/utils.py          # fix ValueError: bad 'value'
├── prisma/                       # Schéma Prisma (SQLite)
├── db/                           # Base SQLite
├── package.json / bun.lock       # Dépendances Next.js
└── Caddyfile                     # Gateway sandbox
```

## Patches appliqués à pdf2zh (déjà inclus dans `patches/`)

1. **Traducteur Google gratuit** : `translator.py` utilise l'endpoint
   `clients5.google.com/translate_a/t?client=dict-chrome-ex`
   (translate.googleapis.com est bloqué dans certains environnements).
2. **Italiques traduits** : `converter.py` — la regex des « polices de formules »
   ne contient plus `.*Ital`, pour que les passages en italique soient traduits.
3. **Pas de version bilingue** : `high_level.py` — la variable d'environnement
   `BABELIVRE_NO_DUAL=1` court-circuite l'assemblage du PDF dual (gain de RAM/temps).
4. **OCR robuste** : assainissement des boîtes + fallback `insert_textbox`
   (corrige l'`OverflowError` sur les PDF scannés).
5. **pymupdf/utils.py** : fix `ValueError: bad 'value'` dans `set_old_widths`.
6. **Fusion des fragments de ligne** (v2) : `converter.py` — le modèle de mise en
   page coupe parfois une ligne en plusieurs régions (« …Orde » + « r. ») ;
   les régions adjacentes d'une même ligne sont refusionnées AVANT traduction.

## Compositeur de flux (v2/v3) — `flow_compose.py`

- **Césure française** (pyphen) pour des lignes pleines et une justification propre.
- **Indentation à la première ligne seulement** (les lignes suivantes utilisent
  toute la largeur de colonne).
- **Contrôle des veuves** : un mot isolé en fin de paragraphe est remonté
  (compression légère de l'intermot) ou accompagné du mot précédent ; jamais de
  mot seul en bas de page.
- **Sommaires / listes** : les blocs d'entrées courts fusionnés par le modèle
  sont redécoupés en une entrée par ligne (traduction ligne par ligne).
- **Séparateurs de scène** : les glyphes isolés (●, *) sont centrés avec un
  espacement vertical, au lieu de rester collés à la marge.
- **Phrases recollées** : une phrase coupée en deux blocs (ou deux pages) par le
  modèle est recomposée en un seul paragraphe.
- **Dialogues espacés** (v3) : les paragraphes commençant par un guillemet
  ouvrant (« “ ") ne reçoivent pas d'alinéa de première ligne ; ils gardent
  ainsi l'espacement de paragraphe entre chaque tour de parole, comme dans un
  livre imprimé.

## Installation (Linux / macOS, avec Bun + Python 3.12)

```bash
# 1. Frontend Next.js (port 3000)
bun install
bun run db:push        # initialise la base SQLite
bun run dev &          # démarre sur http://localhost:3000

# 2. Service de traduction (port 3050)
cd mini-services/pdf-translate
bun install

# 3. Venv Python avec pdf2zh 1.9.11 + césure française
python3.12 -m venv venv
./venv/bin/pip install 'pdf2zh==1.9.11' 'pymupdf==1.25.2' 'pdf2zh[ocr]' pyphen

# 4. Écraser avec les fichiers patchés
cp -r ../../patches/pdf2zh/*          venv/lib/python3.12/site-packages/pdf2zh/
cp    ../../patches/pymupdf/utils.py  venv/lib/python3.12/site-packages/pymupdf/utils.py

# 5. Lancer le service
bun run dev
curl http://127.0.0.1:3050/api/health   # doit répondre {"status":"ok",...}
```

## Utilisation

1. Ouvrez http://localhost:3000
2. Déposez un PDF en anglais
3. Attendez la fin de la traduction (barre de progression par pages)
4. Cliquez « Télécharger en français » — un seul PDF, entièrement en français,
   pages complètes, marqueurs « — suite de la page N — » là où le texte continue.

## Test en ligne de commande (sans l'app)

```bash
cd mini-services/pdf-translate
./venv/bin/python translate_job.py livre.pdf outdir \
    --pdf2zh ./venv/bin/pdf2zh -li en -lo fr -s google -t 1 --chunk-pages 50
```

## Notes techniques

- Traduction par blocs de **50 pages** avec re-découpage récursif si le
  processus est tué par manque de mémoire (exit -9 / 137), puis fusion
  (`garbage=4, deflate=True`) et recomposition finale via `flow_compose.py`.
- Machine de référence : 4 Go RAM, sans swap. `BABELIVRE_NO_DUAL=1` est
  essentiel pour rester sous la limite.
- Aucune donnée n'est conservée : les fichiers temporaires sont dans
  `mini-services/pdf-translate/jobs/` (non inclus dans l'archive).
