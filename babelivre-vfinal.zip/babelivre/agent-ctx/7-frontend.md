# Task 7 — Babelivre Frontend (Next.js)

**Status: DONE** · Lint: clean (0 errors) · Page compiles & renders (`GET / 200`)

## Files created
- `src/lib/upstream.ts` — `UPSTREAM_BASE = "http://127.0.0.1:3050"` (server-side only).
- `src/app/api/health/route.ts` — GET proxy, 5s timeout → `{ok:true}` / 503 `{ok:false}`.
- `src/app/api/translate/route.ts` — POST multipart proxy (file, sourceLang, targetLang) → forwards FormData to upstream `/api/translate`; validates file presence; 400/502 on errors; `maxDuration = 3600`.
- `src/app/api/translate/status/route.ts` — GET `?jobId=` proxy to upstream `/api/status`; 400 if jobId missing; 502 on network failure.
- `src/app/api/translate/download/route.ts` — GET `?jobId=&type=mono|dual`; streams upstream `/api/download` with `Content-Type: application/pdf`, `Content-Disposition: attachment; filename="babelivre-{sanitizedJobId}.pdf"`; passes through 404.
- `src/app/api/translate/preview/route.ts` — same but `inline` disposition.
- `src/components/translator/types.ts` — `TranslateStatus`, `StatusResponse` (incl. optional `hasMono`/`hasDual`), `TranslateResponse`, `MAX_FILE_SIZE` (50 Mo), `formatFileSize`.
- `src/components/translator/upload-view.tsx` — drag & drop + file picker (PDF only, ≤50 Mo), selected file chip with remove, EN→FR badges with ArrowRight, amber submit button with loading spinner, toasts via `@/hooks/use-toast` + existing `<Toaster/>`.
- `src/components/translator/progress-view.tsx` — amber Progress bar, French phase text (En attente… / Traduction en cours… {done}/{total} pages / Terminé !), file name + jobId, Retour button.
- `src/components/translator/done-view.tsx` — "Télécharger en français" primary (download route), "Traduire un autre livre" reset, flow-layout note (« suite de la page X »), inline `<object>` preview (max-h 600px) of preview route.
- `src/components/translator/error-view.tsx` — friendly French error mapping (scanned/OCR, password-protected, corrupt, timeout, network), Réessayer button.
- `src/components/translator/translator-app.tsx` — client orchestrator; polls status every 1500 ms only during `progress` phase, cleanup stops polling; transitions to done/error views automatically.

## Files modified
- `src/app/layout.tsx` — French metadata ("Babelivre — Traduction de livres PDF en français"), `lang="fr"`, kept fonts/globals/Toaster.
- `src/app/page.tsx` — full rebuild: sticky header (BookOpen amber logo + "Gratuit" badge), hero with 3 feature chips, TranslatorApp card, 4 feature cards, 4-question FAQ accordion, sticky footer (`min-h-screen flex flex-col` + `mt-auto` + safe-area padding).

## Design
Papier/ambre theme: `bg-stone-50` / `dark:bg-stone-950`, amber-600/700 accents. **No blue/indigo anywhere.** framer-motion v12 was in package.json → used for subtle view transitions. Lucide icons only, no emojis. Responsive mobile-first, ≥44px touch targets, aria-labels, semantic header/main/section/footer.

## Notes for the main agent
- Verified `/api/health` returns 503 `{ok:false}` right now — expected, since upstream :3050 (Python backend) is not running yet. Once it starts, health will flip to 200.
- Client only ever uses relative paths (`/api/translate`, `/api/translate/status?...`, `/api/translate/download?...`, `/api/translate/preview?...`). No absolute URLs client-side, no ports needed since all traffic goes through Next.js proxy routes on port 3000.
- `hasDual` is typed but never used in UI (backend currently only produces mono).
